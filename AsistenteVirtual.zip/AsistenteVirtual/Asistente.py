import speech_recognition as sr
import pyttsx3
import pywhatkit
import urllib.request
import json
import datetime
import wikipedia
import tkinter as tk

class App:
    
    def __init__(self):
            
        self.ventana = tk.Tk()
        self.ventana.title("Asistente Virtual")
        self.ventana.geometry("500x400")
        self.ventana.resizable(False,False)

        self.label=tk.Label(self.ventana, text="     ")
        self.label.grid(column=5, row=1)
        self.label.configure(foreground="black")
        
        self.label2=tk.Label(self.ventana, text="   Bienvenidos al ASISTENTE VIRTUAL Alex!! CIERRA PARA HABLAR")
        self.label2.grid(column=6, row=2)
        self.label2.configure(foreground="black")
        
        self.label3=tk.Label(self.ventana, text=" ")
        self.label3.grid(column=7, row=4)
        self.label3.configure(foreground="black")
        self.ventana.mainloop()
    
        
app = App() 

# Nombre del asistente
name = 'alex'

# Clave Api
key = 'AIzaSyB7ZlrBcyRCcYeLkpNuzZNUGWoEYC9iRCM'

# Flag para apagar el programa
flag = 1

listener = sr.Recognizer()

engine = pyttsx3.init()

# Obtiene las voces y escoge la primera.
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[0].id)

# editing default configuration
engine. setProperty('rate', 178)
engine.setProperty('volume', 0.7)

def talk(text):
    '''
        Aqui, el asistente habla.
    '''
    engine.say(text)
    engine.runAndWait()

def listen():
    '''
        Aqui el programa obtiene nuestra voz y activa la funcion.
    '''
    flag = 1
    try:
        with sr.Microphone() as source:
            print("Escuchando...")
            voice = listener.listen(source)
            rec = listener.recognize_google(voice, language='es-ES')
            rec = rec.lower()
            print(rec)
            
            if name in rec:
                rec = rec.replace(name, '')
                flag = run(rec)
            else:
                talk(name + ":" +" Vuelve a intentarlo, no reconozco: " + rec)
    except:
        pass
    return flag

def run(rec):
    '''
        Todas las funciones que el asistente puede hacer
    '''
    if 'reproduce' in rec:
        music = rec.replace('reproduce', '')
        talk('Reproduciendo ' + music)
        pywhatkit.playonyt(music)
    elif 'cuantos suscriptores tiene' in rec:
        name_subs = rec.replace('cuantos suscriptores tiene', '')
        data = urllib.request.urlopen(f'https://www.googleapis.com/youtube/v3/channels?part=statistics&forUsername={name_subs.strip()}&key={key}').read()
        subs = json.loads(data)["items"][0]["statistics"]["subscriberCount"]
        talk(name_subs + " tiene {:,d}".format(int(subs)) + " suscriptores!")
    elif 'hora' in rec:
        hora = datetime.datetime.now().strftime('%I:%M %p')
        talk("Son las " + hora)
    elif 'busca' in rec:
        order = rec.replace('busca', '')
        wikipedia.set_lang("es")
        info = wikipedia.summary(order, 1)
        talk(info)
    elif 'salir' in rec:
        flag = 0
        talk("Saliendo...")
    else:
        talk("Vuelve a intentarlo, no reconozco: " + rec)
    return flag

while flag:
    flag = listen()


